package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class LandingPage {

		// TODO Auto-generated method stub
		WebDriver driver;
		
		public LandingPage(WebDriver driver)
		{
			//initialization
			this.driver=driver;
			PageFactory.initElements(driver, this);
			
		}
			
	
		public void goTo()
		{
			driver.get("https://www.amazon.com/");
		
	}
		public void SearchForToys() {
			
		}
		}


